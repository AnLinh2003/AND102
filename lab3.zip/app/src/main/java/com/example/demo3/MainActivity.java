package com.example.demo3;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
Button btn1, btn2, btn3, btn4;
Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;


        });

        btn1 = findViewById(R.id.btndemo1);
        btn2 = findViewById(R.id.btndemo2);
        btn3 = findViewById(R.id.btndemo3);
        btn4 = findViewById(R.id.btndemo4);

        //1 AlerDailog
        btn1.setOnClickListener(v -> {
            //1.1 tạo builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);

            // 1.2 thêm các thành bần builder
            builder.setTitle("Thông báo");
            builder.setMessage("Nội dung thông báo");
            //1.3 thêm button oke
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(), "Bạn đồng ý ",
                    Toast.LENGTH_LONG).show();
                }
            });
            // Cancel
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(), "Bạn đã Cancel ",
                            Toast.LENGTH_LONG).show();
                }
            });
            //b1.4 tạo dialog trên builder
            AlertDialog alertDialog = builder.create();
            //1.5 hiển thị
            alertDialog.show();
        });

        //-----------
        //Single Choie
        btn2.setOnClickListener(v -> {
            //b1 lấy nguồn dữ liệu
            String[] arr = {"xanh", "Đỏ", "Tím","Vàng"};
            //b2 Tạo buiider
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            // b3 tạo thành phần cho builder
            builder.setTitle("Tiêu đề");
            //B4 Set Single choice cho Alert
            builder.setSingleChoiceItems(arr, 0, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),"Bạn chọn " +arr[which],
                            Toast.LENGTH_LONG).show();
                }
            });
            //b5 tạo dailog tu builder
            AlertDialog alertDialog = builder.create();
            // b6 hiển thị
            alertDialog.show();
        });
        //Multiple choice
        btn3.setOnClickListener(v -> {
            //b1 lấy nguồn dữ liệu
            String[] arr = {"xanh", "Đỏ", "Tím","Vàng"};
            //b2 Tạo buiider
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            // b3 tạo thành phần cho builder
            builder.setTitle("Tiêu đề");
            //B4 Set Multiple  choice cho Alert
            builder.setMultiChoiceItems(arr, null, new DialogInterface.OnMultiChoiceClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                    Toast.makeText(getApplicationContext(),"Bạn chọn " +arr[which],
                            Toast.LENGTH_LONG).show();
                }
            });


            //b5 tạo dailog tu builder
            AlertDialog alertDialog = builder.create();
            // b6 hiển thị
            alertDialog.show();
        });
        btn4.setOnClickListener(v -> {
            //b1 Tạo builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            // b2 gán layout
            LayoutInflater inflater = getLayoutInflater();
            View view1 = inflater.inflate(R.layout.login, null);
            builder.setView(view1); // Đưa view vào builder

            // Ánh xạ các thành phần
            final EditText txUser = (EditText) view1.findViewById(R.id.login_txUser);
            final EditText txPass = (EditText) view1.findViewById(R.id.login_txPass);
            // Thêm các thành phần khác: title, from, cancel
            builder.setTitle("Login From");
            builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),
                            "Xin chào " +txUser.getText().toString(), Toast.LENGTH_LONG).show();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(),
                            "Logout", Toast.LENGTH_LONG).show();
                }
            });
            // B5 tạo dialog
            AlertDialog alertDialog = builder.create();
            // b6 hiển thị
            alertDialog.show();
        });
    }
}