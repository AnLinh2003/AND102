package com.example.demo5;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

public class demo52 extends AppCompatActivity {

    ViewPager viewPager;
    TabLayout tabLayout;
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_demo52);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        viewPager = findViewById(R.id.demo53_viewPager);
        tabLayout = findViewById(R.id.demo53_tabLayout);
        addTabLayouut(viewPager);
        tabLayout.setupWithViewPager(viewPager);
        drawerLayout = findViewById(R.id.drawer_layout_demo52);
        NavigationView navigationView = findViewById(R.id.nav_view52);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.demo51_menu_item1){
                   viewPager.setCurrentItem(0);
                   closeDrawer();
                   return true;
                }
                if (item.getItemId() == R.id.demo51_menu_item2){
                    viewPager.setCurrentItem(1);
                    closeDrawer();
                    return true;
                }
                if (item.getItemId() == R.id.demo51_menu_item3){
                    viewPager.setCurrentItem(2);
                    closeDrawer();
                    return true;
                }
                return false;
            }
        });
    }

    public void closeDrawer(){
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }
    public void  addTabLayouut(ViewPager viewPager){
        // Tạo mới adapter
        Demo53Adapter adapter = new Demo53Adapter(getSupportFragmentManager());
        // Thêm fragment vào adapter
        adapter.addFrag(new BlankFragment1(), "ONE");
        adapter.addFrag(new BlankFragment2(), "TWo");
        adapter.addFrag(new BlankFragment3(), "THREE");
        //
        viewPager.setAdapter(adapter);

    }
}