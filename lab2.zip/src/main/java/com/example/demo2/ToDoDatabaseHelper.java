package com.example.demo2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ToDoDatabaseHelper extends SQLiteOpenHelper {
    public ToDoDatabaseHelper(Context context) {
        super(context, "todolist.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE todos(\n" +
                "\tid integer PRIMARY KEY AUTOINCREMENT,\n" +
                "  \ttitle text,\n" +
                "  content text,\n" +
                "  date text,\n" +
                "  type text,\n" +
                "  status integer \n" +
                ")";
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    db.execSQL("DROP TABLE IF EXISTS todos");
    }
}
