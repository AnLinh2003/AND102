package com.example.demo2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ToDoDAO {
    private SQLiteDatabase db;
    public ToDoDAO(Context context){
        ToDoDatabaseHelper dbHelper = new ToDoDatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    // thêm dữ liệu
    public long addTodo(ToDo toDo){
        ContentValues values = new ContentValues();
        values.put("title", toDo.getTitle());
        values.put("content", toDo.getContent());
        values.put("date", toDo.getDate());
        values.put("type", toDo.getType());
        values.put("status", toDo.getStatus());
        return db.insert("todos",null,values);
    }
    // Lấy dữ liệu
    public List<ToDo> getAllTodos(){
        List<ToDo> todos = new ArrayList<>();
        Cursor cursor = db.query("todos",  null, null,
                null,null, null,"id DESC");
        if (cursor.moveToFirst()){// di chuyển về bản ghhi đầu tiên
            do {
                @SuppressLint("Range") ToDo todo = new ToDo(
                        cursor.getString(cursor.getColumnIndex("title")),
                  cursor.getString(cursor.getColumnIndex("content")),
                  cursor.getString(cursor.getColumnIndex("date")),
                  cursor.getString(cursor.getColumnIndex("type")),
                  cursor.getInt(cursor.getColumnIndex("status"))
                );
                todos.add(todo);
            }while (cursor.moveToNext());
        }
        cursor.close();
        return todos;
    }
    // update trạng thái
    public  void updateTodoStatus(int id, int status){
        ContentValues values = new ContentValues();
        values.put("status", status);
        db.update("todos", values,"id=?", new String[]{String.valueOf(id)});
    }
// update bảng dữ liệu
    public void updateTodo(ToDo todo){
        ContentValues values = new ContentValues();
        values.put("title", todo.getTitle());
        values.put("content", todo.getContent());
        values.put("date", todo.getDate());
        values.put("type", todo.getType());
        values.put("status", todo.getStatus());
        db.update("todos", values, "id=?", new String[]{String.valueOf(todo.getId())});
    }
    // Xóa dữ liệu
    public void deleteTodo(int id){
        db.delete("todos", "id=?", new String[]{String.valueOf(id)});
    }
}
