package com.example.demo2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.TodoViewHolder> {

    private List<ToDo> todoList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDeleteClick(int position);
        void onEditClick(int position);
        void onStatusClick(int position, boolean isDone);
        void onCheckedChanged(int position, boolean isChecked);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public ToDoAdapter(List<ToDo> todoList) {
        this.todoList = todoList;
    }

    @NonNull
    @Override
    public TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.demo2_item_view, parent, false);
        return new TodoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoViewHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return todoList.size();
    }

    public class TodoViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvContent, tvDate, tvTyper;
        Button btnEdit, btnDelete;
        CheckBox checkBox;

        public TodoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.itemTVTitle);
            tvContent = itemView.findViewById(R.id.itemTVContent);
            tvDate = itemView.findViewById(R.id.itemTVDate);
            tvTyper = itemView.findViewById(R.id.itemTVTyper);
            btnEdit = itemView.findViewById(R.id.item_Btn_Edit);
            btnDelete = itemView.findViewById(R.id.item_Btn_Delete);
            checkBox = itemView.findViewById(R.id.itemCheckBox);

            // Xử lý sự kiện khi click vào nút Delete
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onDeleteClick(position);
                    }
                }
            });

            // Xử lý sự kiện khi click vào nút Edit
            btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onEditClick(position);
                    }
                }
            });

            // Xử lý sự kiện khi thay đổi trạng thái của CheckBox
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onCheckedChanged(position, isChecked);
                    }
                }
            });
        }

        public void bind(int position) {
            ToDo currentTodo = todoList.get(position);
            tvTitle.setText(currentTodo.getTitle());
            tvContent.setText(currentTodo.getContent());
            tvDate.setText(currentTodo.getDate());
            tvTyper.setText(currentTodo.getType());

            // Thiết lập trạng thái của CheckBox mà không gây ra lỗi IllegalStateException
            checkBox.setChecked(currentTodo.getStatus() == 1);

            // Khi bind, không gọi checkBox.setChecked() ở đây để tránh gây ra lỗi IllegalStateException
        }
    }
}
