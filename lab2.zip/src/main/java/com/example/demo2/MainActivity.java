package com.example.demo2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.demo2.ToDo;
import com.example.demo2.ToDoAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<ToDo> todoList;
    private RecyclerView recyclerView;
    private ToDoAdapter adapter;
    private EditText edtTitle, edtContent, edtDate, edtTyper;
    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Khởi tạo RecyclerView và adapter
        recyclerView = findViewById(R.id.Recy);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        todoList = new ArrayList<>();
        adapter = new ToDoAdapter(todoList);

        // Thiết lập adapter cho RecyclerView
        recyclerView.setAdapter(adapter);

        // Ánh xạ EditText và Button từ layout
        edtTitle = findViewById(R.id.edtTitle);
        edtContent = findViewById(R.id.edtContent);
        edtDate = findViewById(R.id.edtDate);
        edtTyper = findViewById(R.id.edtTyper);
        btnAdd = findViewById(R.id.btnAdd);

        // Xử lý sự kiện thêm công việc mới khi click vào nút Add
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = edtTitle.getText().toString().trim();
                String content = edtContent.getText().toString().trim();
                String date = edtDate.getText().toString().trim();
                String typer = edtTyper.getText().toString().trim();

                if (!title.isEmpty() && !content.isEmpty() && !date.isEmpty() && !typer.isEmpty()) {
                    // Thêm một công việc mới vào danh sách
                    ToDo newToDo = new ToDo(title, content, date, typer, 0); // Thay thế bằng dữ liệu thực tế của bạn
                    todoList.add(newToDo);
                    adapter.notifyItemInserted(todoList.size() - 1); // Thông báo cho adapter là có thêm một item mới

                    // Xóa nội dung trong EditText sau khi thêm
                    edtTitle.setText("");
                    edtContent.setText("");
                    edtDate.setText("");
                    edtTyper.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Thiết lập các sự kiện của adapter
        adapter.setOnItemClickListener(new ToDoAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(int position) {
                if (position >= 0 && position < todoList.size()) {
                    // Xóa công việc khi click vào nút Delete
                    todoList.remove(position);
                    adapter.notifyItemRemoved(position);
                }
            }

            @Override
            public void onEditClick(int position) {
                // Xử lý sự kiện chỉnh sửa khi click vào nút Edit
                showEditDialog(position);
            }

            @Override
            public void onStatusClick(int position, boolean isDone) {
                // Xử lý sự kiện thay đổi trạng thái khi click vào item
                ToDo todo = todoList.get(position);
                todo.setStatus(isDone ? 1 : 0);
                // Không cần gọi notifyItemChanged(position) ở đây để tránh lỗi IllegalStateException
            }

            @Override
            public void onCheckedChanged(int position, boolean isChecked) {
                // Xử lý sự kiện thay đổi checkbox khi click vào item
                ToDo todo = todoList.get(position);
                todo.setStatus(isChecked ? 1 : 0);
                // Không cần gọi notifyItemChanged(position) ở đây để tránh lỗi IllegalStateException
            }
        });
    }

    // Phương thức hiển thị dialog chỉnh sửa
    private void showEditDialog(final int position) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_edit_todo, null);
        dialogBuilder.setView(dialogView);

        EditText editTitle = dialogView.findViewById(R.id.editTitle);
        EditText editContent = dialogView.findViewById(R.id.editContent);
        EditText editDate = dialogView.findViewById(R.id.editDate);
        EditText editTyper = dialogView.findViewById(R.id.editTyper);
        Button btnUpdate = dialogView.findViewById(R.id.btnUpdate);

        // Đổ dữ liệu hiện tại vào dialog
        ToDo currentTodo = todoList.get(position);
        editTitle.setText(currentTodo.getTitle());
        editContent.setText(currentTodo.getContent());
        editDate.setText(currentTodo.getDate());
        editTyper.setText(currentTodo.getType());

        final AlertDialog alertDialog = dialogBuilder.create();

        // Xử lý sự kiện khi click vào nút Update trong dialog
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newTitle = editTitle.getText().toString().trim();
                String newContent = editContent.getText().toString().trim();
                String newDate = editDate.getText().toString().trim();
                String newTyper = editTyper.getText().toString().trim();

                if (!newTitle.isEmpty() && !newContent.isEmpty() && !newDate.isEmpty() && !newTyper.isEmpty()) {
                    // Cập nhật thông tin công việc
                    ToDo updatedTodo = new ToDo(newTitle, newContent, newDate, newTyper, currentTodo.getStatus());
                    todoList.set(position, updatedTodo);
                    adapter.notifyItemChanged(position);

                    alertDialog.dismiss(); // Đóng dialog sau khi cập nhật
                } else {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                }
            }
        });

        alertDialog.show();
    }
}
