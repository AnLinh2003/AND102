package com.example.asm;

import android.app.DatePickerDialog;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Calendar;

public class GratitudeActivity extends AppCompatActivity {

    EditText etGratitudeMessage;
    Button btnAddGratitude;
    ListView lvGratitudeList;
    ImageButton btnBack;
    DatePickerDialog datePickerDialog;
    TextView tvDate;

    ArrayList<Gratitude> gratitudeList;
    GratitudeAdapter gratitudeAdapter;
    GratitudeDatabaseHelper dbHelper;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gratitude);

        // Ánh xạ views
        etGratitudeMessage = findViewById(R.id.etGratitudeMessage);
        btnAddGratitude = findViewById(R.id.btnAddGratitude);
        lvGratitudeList = findViewById(R.id.lvGratitudeList);
        btnBack = findViewById(R.id.btnBack);
        tvDate = findViewById(R.id.tvDate);

        // Khởi tạo cơ sở dữ liệu và adapter
        dbHelper = new GratitudeDatabaseHelper(this);
        database = dbHelper.getWritableDatabase();
        gratitudeList = new ArrayList<>();
        gratitudeAdapter = new GratitudeAdapter(this, R.layout.list_item_gratitude, gratitudeList, database);
        lvGratitudeList.setAdapter(gratitudeAdapter);

        // Xử lý sự kiện thêm lời biết ơn
        btnAddGratitude.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = etGratitudeMessage.getText().toString().trim();
                String date = tvDate.getText().toString();
                if (!message.isEmpty()) {
                    Gratitude gratitude = new Gratitude(gratitudeList.size() + 1, message, date);
                    gratitudeAdapter.addGratitudeToDatabase(gratitude);
                    etGratitudeMessage.setText("");
                    tvDate.setText(""); // Xóa dữ liệu ngày sau khi thêm
                } else {
                    Toast.makeText(GratitudeActivity.this, "Vui lòng nhập lời biết ơn", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Xử lý sự kiện nút quay lại MainActivity
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // Xử lý sự kiện chọn ngày tháng
        tvDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
    }

    private void showDatePickerDialog() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                tvDate.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
            }
        };

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        datePickerDialog = new DatePickerDialog(this, dateSetListener, year, month, day);
        datePickerDialog.show();
    }
}
