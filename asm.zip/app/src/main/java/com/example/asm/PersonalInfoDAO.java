package com.example.asm;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class PersonalInfoDAO {

    private SQLiteDatabase database;
    private PersonalInfoDatabaseHelper dbHelper;

    private String[][] menuSuggestions = {
            {"Salad gà nướng", "Sinh tố trái cây"},
            {"Bánh sandwich lúa mạch", "Hạt hỗn hợp"},
            {"Cá hồi nướng rau củ", "Salad quinoa"},
            {"Thịt bò nạc với gạo lứt", "Salad xanh với sốt dầu ô-liu"}
    };
    private String[][] menuSuggestionsPii = {
            {"Bạn cần bổ sung thêm chất béo và protein để tăng cân."},
            {"Bạn nên duy trì chế độ ăn uống cân bằng."},
            {"Bạn nên giảm thiểu đường và chất béo, tăng cường vận động."},
            {"Bạn cần giảm cân và tập luyện thường xuyên hơn."}
    };


    public PersonalInfoDAO(Context context) {
        dbHelper = new PersonalInfoDatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long addPersonalInfo(PersonalInfo info) {
        ContentValues values = new ContentValues();
        values.put(PersonalInfoDatabaseHelper.COLUMN_GENDER, info.getGender());
        values.put(PersonalInfoDatabaseHelper.COLUMN_HEIGHT, info.getHeight());
        values.put(PersonalInfoDatabaseHelper.COLUMN_WEIGHT, info.getWeight());
        values.put(PersonalInfoDatabaseHelper.COLUMN_BMI, info.getBmi());

        open(); // Mở database trước khi thao tác
        long id = database.insert(PersonalInfoDatabaseHelper.TABLE_PERSONAL_INFO, null, values);
        close(); // Đóng database sau khi thao tác

        return id;
    }

    public List<PersonalInfo> getAllPersonalInfo() {
        List<PersonalInfo> infoList = new ArrayList<>();

        open(); // Mở database trước khi truy vấn
        Cursor cursor = database.query(PersonalInfoDatabaseHelper.TABLE_PERSONAL_INFO,
                null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                PersonalInfo info = cursorToPersonalInfo(cursor);
                infoList.add(info);
            } while (cursor.moveToNext());
            cursor.close();
        }

        close(); // Đóng database sau khi truy vấn
        return infoList;
    }

    @SuppressLint("Range")
    private PersonalInfo cursorToPersonalInfo(Cursor cursor) {
        PersonalInfo info = new PersonalInfo();
        info.setId(cursor.getInt(cursor.getColumnIndex(PersonalInfoDatabaseHelper.COLUMN_ID)));
        info.setGender(cursor.getString(cursor.getColumnIndex(PersonalInfoDatabaseHelper.COLUMN_GENDER)));
        info.setHeight(cursor.getFloat(cursor.getColumnIndex(PersonalInfoDatabaseHelper.COLUMN_HEIGHT)));
        info.setWeight(cursor.getFloat(cursor.getColumnIndex(PersonalInfoDatabaseHelper.COLUMN_WEIGHT)));
        info.setBmi(cursor.getFloat(cursor.getColumnIndex(PersonalInfoDatabaseHelper.COLUMN_BMI)));
        return info;
    }

    public void deletePersonalInfo(long id) {
        open(); // Mở database trước khi xóa
        database.delete(PersonalInfoDatabaseHelper.TABLE_PERSONAL_INFO,
                PersonalInfoDatabaseHelper.COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        close(); // Đóng database sau khi xóa
    }

    public int getBMICategory(float bmi) {
        // Định nghĩa các khoảng BMI
        if (bmi < 18.5) {
            return 0; // Gầy
        } else if (bmi < 24.9) {
            return 1; // Bình thường
        } else if (bmi < 29.9) {
            return 2; // Thừa cân
        } else {
            return 3; // Béo phì
        }
    }

    public String showMenuSuggestions(int bmiCategory, Context context) {
        // Gợi ý thực đơn dựa vào khoảng BMI
        if (bmiCategory >= 0 && bmiCategory < menuSuggestions.length) {
            StringBuilder sb = new StringBuilder();
            sb.append("Gợi ý thực đơn cho bạn:\n");
            for (String suggestion : menuSuggestions[bmiCategory]) {
                sb.append("- ").append(suggestion).append("\n");
            }
            return sb.toString();
        } else {
            return "Không có gợi ý thực đơn cho chỉ số BMI này.";
        }
    }

    public String showMenuSugg(int bmiCategory, Context context) {
        // Gợi ý thực đơn dựa vào khoảng BMI
        if (bmiCategory >= 0 && bmiCategory < menuSuggestionsPii.length) {
            StringBuilder sb = new StringBuilder();
            sb.append("Lời khuyên: \n");
            for (String suggestion : menuSuggestionsPii[bmiCategory]) {
                sb.append("- ").append(suggestion).append("\n");
            }
            return sb.toString();
        } else {
            return "Không có lời khuyên cho chỉ số BMI này.";
        }
    }

}
