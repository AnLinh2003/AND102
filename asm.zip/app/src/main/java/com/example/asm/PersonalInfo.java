package com.example.asm;

public class PersonalInfo {

    private int id;
    private String gender;
    private float height;
    private float weight;
    private float bmi;

    public PersonalInfo() {
        // Default constructor
    }

    public PersonalInfo(String gender, float height, float weight, float bmi) {
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.bmi = bmi;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public float getBmi() {
        return bmi;
    }

    public void setBmi(float bmi) {
        this.bmi = bmi;
    }

    // Phương thức để gợi ý thực đơn dựa trên chỉ số BMI
    public String[] getMenuSuggestions() {
        String[][] menuSuggestions = {
                {"Salad gà nướng", "Sinh tố trái cây"},
                {"Bánh sandwich lúa mạch", "Hạt hỗn hợp"},
                {"Cá hồi nướng rau củ", "Salad quinoa"},
                {"Thịt bò nạc với gạo lứt", "Salad xanh với sốt dầu ô-liu"}
        };

        int bmiCategory = getBMICategory();
        if (bmiCategory >= 0 && bmiCategory < menuSuggestions.length) {
            return menuSuggestions[bmiCategory];
        } else {
            return new String[0]; // Trả về mảng rỗng nếu không có gợi ý
        }
    }

    // Phương thức để xác định danh mục BMI
    private int getBMICategory() {
        if (bmi < 18.5) {
            return 0; // Gầy
        } else if (bmi < 24.9) {
            return 1; // Bình thường
        } else if (bmi < 29.9) {
            return 2; // Thừa cân
        } else {
            return 3; // Béo phì
        }
    }
}
