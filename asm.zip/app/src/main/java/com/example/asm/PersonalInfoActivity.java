package com.example.asm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class PersonalInfoActivity extends AppCompatActivity {

    private EditText etHeight, etWeight;
    private RadioGroup radioGroupGender;
    private RadioButton rbMale, rbFemale;
    private Button btnAdd;
    private ListView lvPersonalInfo;
    private PersonalInfoDAO personalInfoDAO;
    private PersonalInfoAdapter adapter;
    ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);

        // Khởi tạo các view
        etHeight = findViewById(R.id.etHeight);
        etWeight = findViewById(R.id.etWeight);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        btnAdd = findViewById(R.id.btnAddBMI);
        btnBack = findViewById(R.id.btnBack);
        lvPersonalInfo = findViewById(R.id.lvBMIResults);

        // Khởi tạo DAO và mở kết nối
        personalInfoDAO = new PersonalInfoDAO(this);
        personalInfoDAO.open();

        // Khởi tạo adapter và thiết lập ListView
        List<PersonalInfo> infoList = personalInfoDAO.getAllPersonalInfo();
        adapter = new PersonalInfoAdapter(this, R.layout.list_item_personal_info, infoList);
        lvPersonalInfo.setAdapter(adapter);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        // Sự kiện click cho nút thêm thông tin cá nhân
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInput()) {
                    addPersonalInfo();
                } else {
                    Toast.makeText(PersonalInfoActivity.this, "Vui lòng nhập đầy đủ chiều cao và cân nặng.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateInput() {
        String heightStr = etHeight.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();

        return !heightStr.isEmpty() && !weightStr.isEmpty();
    }

    private void addPersonalInfo() {
        // Lấy dữ liệu từ các trường nhập
        String gender = rbMale.isChecked() ? "Nam" : "Nữ";
        float height = Float.parseFloat(etHeight.getText().toString());
        float weight = Float.parseFloat(etWeight.getText().toString());
        float bmi = calculateBMI(height, weight);

        // Tạo đối tượng PersonalInfo mới
        PersonalInfo info = new PersonalInfo(gender, height, weight, bmi);

        // Thêm vào cơ sở dữ liệu và nhận kết quả
        long result = personalInfoDAO.addPersonalInfo(info);

        if (result != -1) {
            // Hiển thị thông báo thành công
            Toast.makeText(this, "Thêm thông tin thành công!", Toast.LENGTH_SHORT).show();

            // Cập nhật danh sách thông tin cá nhân từ cơ sở dữ liệu
            List<PersonalInfo> updatedInfoList = personalInfoDAO.getAllPersonalInfo();

            // Cập nhật adapter và ListView
            adapter.clear();
            adapter.addAll(updatedInfoList);
            adapter.notifyDataSetChanged();

            // Hiển thị gợi ý thực đơn dựa trên chỉ số BMI
            int bmiCategory = personalInfoDAO.getBMICategory(bmi);
            personalInfoDAO.showMenuSuggestions(bmiCategory, this);
            personalInfoDAO.showMenuSugg(bmiCategory, this);
        } else {
            // Hiển thị thông báo thất bại
            Toast.makeText(this, "Thêm thông tin thất bại!", Toast.LENGTH_SHORT).show();
        }
    }

    private float calculateBMI(float height, float weight) {
        // Tính chỉ số BMI
        return weight / ((height / 100) * (height / 100));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Đóng kết nối đến cơ sở dữ liệu
        personalInfoDAO.close();
    }
    public void backToMainActivity(View view) {
        finish(); // Đóng Activity hiện tại
    }
}
