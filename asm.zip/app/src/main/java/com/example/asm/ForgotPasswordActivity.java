package com.example.asm;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etOldPassword;
    private EditText etNewPassword;
    private EditText etConfirmPassword;
    private Button btnCancel;
    private Button btnSubmit;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_for_got_pass);

        // Khởi tạo các view
        etUsername = findViewById(R.id.etUsername);
        etOldPassword = findViewById(R.id.etOldPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnCancel = findViewById(R.id.btnCancel);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Khởi tạo DBHelper
        dbHelper = new DBHelper(this);

        // Thiết lập sự kiện click cho các nút
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý sự kiện click nút hủy bỏ
                finish(); // Đóng activity
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý sự kiện click nút đồng ý
                String username = etUsername.getText().toString().trim();
                String oldPassword = etOldPassword.getText().toString().trim();
                String newPassword = etNewPassword.getText().toString().trim();
                String confirmPassword = etConfirmPassword.getText().toString().trim();

                if (validateInput(username, oldPassword, newPassword, confirmPassword)) {
                    // Tiến hành logic thay đổi mật khẩu
                    if (changePassword(username, oldPassword, newPassword)) {
                        Toast.makeText(ForgotPasswordActivity.this, "Đổi mật khẩu thành công", Toast.LENGTH_SHORT).show();
                        finish(); // Đóng activity sau khi đổi mật khẩu thành công
                    } else {
                        Toast.makeText(ForgotPasswordActivity.this, "Đổi mật khẩu thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private boolean validateInput(String username, String oldPassword, String newPassword, String confirmPassword) {
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Tên tài khoản không được để trống");
            return false;
        }
        if (TextUtils.isEmpty(oldPassword)) {
            etOldPassword.setError("Mật khẩu cũ không được để trống");
            return false;
        }
        if (TextUtils.isEmpty(newPassword)) {
            etNewPassword.setError("Mật khẩu mới không được để trống");
            return false;
        }
        if (TextUtils.isEmpty(confirmPassword)) {
            etConfirmPassword.setError("Xác nhận mật khẩu không được để trống");
            return false;
        }
        if (!newPassword.equals(confirmPassword)) {
            etConfirmPassword.setError("Mật khẩu xác nhận không khớp");
            return false;
        }
        return true;
    }

    private boolean changePassword(String username, String oldPassword, String newPassword) {
        // Sử dụng DBHelper để thay đổi mật khẩu
        DBHelper dbHelper = new DBHelper(this);

        // Kiểm tra mật khẩu cũ
        if (dbHelper.updatePassword(username, oldPassword, newPassword)) {
            // Nếu mật khẩu được cập nhật thành công
            return true;
        } else {
            // Nếu mật khẩu không khớp
            return false;
        }
    }
}
