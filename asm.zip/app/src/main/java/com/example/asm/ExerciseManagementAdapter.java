package com.example.asm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ExerciseManagementAdapter extends ArrayAdapter<ExerciseManagement> {

    private Context context;
    private int resource;
    private List<ExerciseManagement> exerciseList;

    public ExerciseManagementAdapter(Context context, int resource, List<ExerciseManagement> exerciseList) {
        super(context, resource, exerciseList);
        this.context = context;
        this.resource = resource;
        this.exerciseList = exerciseList;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(resource, parent, false);

            holder = new ViewHolder();
            holder.tvDate = convertView.findViewById(R.id.tvDate);
            holder.tvTotalSteps = convertView.findViewById(R.id.tvTotalSteps);
            holder.tvGoalSteps = convertView.findViewById(R.id.tvGoalSteps);
            holder.btnEdit = convertView.findViewById(R.id.btnEdit);
            holder.btnDelete = convertView.findViewById(R.id.btnDelete);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final ExerciseManagement exercise = exerciseList.get(position);

        holder.tvDate.setText(exercise.getDate());
        holder.tvTotalSteps.setText(String.valueOf(exercise.getTotalSteps()));
        holder.tvGoalSteps.setText(String.valueOf(exercise.getGoalSteps()));

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý hành động chỉnh sửa (nếu cần)
                Toast.makeText(context, "Đã nhấn chỉnh sửa vị trí " + position, Toast.LENGTH_SHORT).show();
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý hành động xóa
                exerciseList.remove(position);
                notifyDataSetChanged();
                Toast.makeText(context, "Đã xóa mục tại vị trí " + position, Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }

    static class ViewHolder {
        TextView tvDate;
        TextView tvTotalSteps;
        TextView tvGoalSteps;
        ImageButton btnEdit;
        ImageButton btnDelete;
    }
}
