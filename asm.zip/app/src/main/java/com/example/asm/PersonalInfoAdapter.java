package com.example.asm;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class PersonalInfoAdapter extends ArrayAdapter<PersonalInfo> {

    private Context context;
    private List<PersonalInfo> infoList;
    private PersonalInfoDAO dao;

    public PersonalInfoAdapter(Context context, int resource, List<PersonalInfo> infoList) {
        super(context, resource, infoList);
        this.context = context;
        this.infoList = infoList;
        dao = new PersonalInfoDAO(context); // Khởi tạo DAO ở đây
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_personal_info, parent, false);

            holder = new ViewHolder();
            holder.tvGender = convertView.findViewById(R.id.tvGender);
            holder.tvHeight = convertView.findViewById(R.id.tvHeight);
            holder.tvWeight = convertView.findViewById(R.id.tvWeight);
            holder.tvBMI = convertView.findViewById(R.id.tvBMI);
            holder.tvDietaryRecommendationsLabel = convertView.findViewById(R.id.tvDietaryRecommendationsLabel);
            holder.tvMenuSuggestionsLabel = convertView.findViewById(R.id.tvMenuSuggestionsLabel);
            holder.tvDietaryRecommendations = convertView.findViewById(R.id.tvDietaryRecommendations);
            holder.tvMenuSuggestions = convertView.findViewById(R.id.tvMenuSuggestions);
            holder.btnDelete = convertView.findViewById(R.id.btnDelete);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final PersonalInfo info = infoList.get(position);

        holder.tvGender.setText("Giới tính: " + info.getGender());
        holder.tvHeight.setText("Chiều cao: " + info.getHeight() + " cm");
        holder.tvWeight.setText("Cân nặng: " + info.getWeight() + " kg");
        holder.tvBMI.setText("BMI: " + info.getBmi());

        // Tính chỉ số BMI và hiển thị gợi ý đồ ăn
        float bmi = info.getBmi();
        int bmiCategory = dao.getBMICategory(bmi);
        String dietaryRecommendations = dao.showMenuSugg(bmiCategory, context);
        String menuSuggestions = dao.showMenuSuggestions(bmiCategory, context);

        // Hiển thị gợi ý đồ ăn và lời khuyên
        holder.tvDietaryRecommendationsLabel.setText("");
        holder.tvDietaryRecommendations.setText(dietaryRecommendations);
        holder.tvMenuSuggestionsLabel.setText("");
        holder.tvMenuSuggestions.setText(menuSuggestions);

        // Xử lý sự kiện khi nhấn vào nút xóa
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteConfirmationDialog(position);
            }
        });

        return convertView;
    }


    private void showDeleteConfirmationDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Xác nhận xóa");
        builder.setMessage("Bạn có chắc chắn muốn xóa thông tin cá nhân này?");
        builder.setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Xóa thông tin cá nhân từ danh sách
                PersonalInfo info = infoList.get(position);
                infoList.remove(position);
                notifyDataSetChanged(); // Cập nhật ListView

                // Xóa thông tin trong database
                dao.open();
                dao.deletePersonalInfo(info.getId());
                dao.close();

                Toast.makeText(context, "Đã xóa thông tin cá nhân", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    static class ViewHolder {
        TextView tvGender;
        TextView tvHeight;
        TextView tvWeight;
        TextView tvBMI;
        TextView tvDietaryRecommendationsLabel, tvMenuSuggestionsLabel;
        TextView tvDietaryRecommendations, tvMenuSuggestions;
        ImageButton btnDelete;
    }

}
