package com.example.asm;

public class ExerciseManagement {
    private int id;
    private String date;
    private int totalSteps;
    private int goalSteps;

    public ExerciseManagement(int id, String date, int totalSteps, int goalSteps) {
        this.id = id;
        this.date = date;
        this.totalSteps = totalSteps;
        this.goalSteps = goalSteps;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getTotalSteps() {
        return totalSteps;
    }

    public void setTotalSteps(int totalSteps) {
        this.totalSteps = totalSteps;
    }

    public int getGoalSteps() {
        return goalSteps;
    }

    public void setGoalSteps(int goalSteps) {
        this.goalSteps = goalSteps;
    }
}
