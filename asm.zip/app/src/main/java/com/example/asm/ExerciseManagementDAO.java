package com.example.asm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ExerciseManagementDAO {
    private ExerciseManagementDBHelper dbHelper;

    public ExerciseManagementDAO(Context context) {
        dbHelper = new ExerciseManagementDBHelper(context);
    }

    public long insertExercise(ExerciseManagement exercise) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ExerciseManagementDBHelper.COLUMN_DATE, exercise.getDate());
        values.put(ExerciseManagementDBHelper.COLUMN_TOTAL_STEPS, exercise.getTotalSteps());
        values.put(ExerciseManagementDBHelper.COLUMN_GOAL_STEPS, exercise.getGoalSteps());
        return db.insert(ExerciseManagementDBHelper.TABLE_NAME, null, values);
    }

    public int updateExercise(ExerciseManagement exercise) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ExerciseManagementDBHelper.COLUMN_DATE, exercise.getDate());
        values.put(ExerciseManagementDBHelper.COLUMN_TOTAL_STEPS, exercise.getTotalSteps());
        values.put(ExerciseManagementDBHelper.COLUMN_GOAL_STEPS, exercise.getGoalSteps());
        return db.update(ExerciseManagementDBHelper.TABLE_NAME, values, ExerciseManagementDBHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(exercise.getId())});
    }

    public int deleteExercise(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        return db.delete(ExerciseManagementDBHelper.TABLE_NAME, ExerciseManagementDBHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    public List<ExerciseManagement> getAllExercises() {
        List<ExerciseManagement> exercises = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(ExerciseManagementDBHelper.TABLE_NAME, null, null, null, null, null, ExerciseManagementDBHelper.COLUMN_DATE + " DESC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(ExerciseManagementDBHelper.COLUMN_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(ExerciseManagementDBHelper.COLUMN_DATE));
                int totalSteps = cursor.getInt(cursor.getColumnIndexOrThrow(ExerciseManagementDBHelper.COLUMN_TOTAL_STEPS));
                int goalSteps = cursor.getInt(cursor.getColumnIndexOrThrow(ExerciseManagementDBHelper.COLUMN_GOAL_STEPS));
                exercises.add(new ExerciseManagement(id, date, totalSteps, goalSteps));
            } while (cursor.moveToNext());
            cursor.close();
        }

        return exercises;
    }
}
