package com.example.asm;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class GratitudeDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "gratitude.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_GRATITUDE = "gratitude";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_MESSAGE = "message";
    public static final String COLUMN_DATE = "date";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_GRATITUDE + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_MESSAGE + " TEXT, " +
                    COLUMN_DATE + " TEXT" +
                    ");";

    public GratitudeDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_GRATITUDE + " ADD COLUMN " + COLUMN_DATE + " TEXT;");
        }
    }
}
