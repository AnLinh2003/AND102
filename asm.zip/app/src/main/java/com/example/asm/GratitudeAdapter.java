package com.example.asm;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class GratitudeAdapter extends ArrayAdapter<Gratitude> {

    private Context context;
    private int resource;
    private List<Gratitude> gratitudeList;
    private SQLiteDatabase database;

    public GratitudeAdapter(Context context, int resource, List<Gratitude> gratitudeList, SQLiteDatabase database) {
        super(context, resource, gratitudeList);
        this.context = context;
        this.resource = resource;
        this.gratitudeList = gratitudeList;
        this.database = database;
        loadGratitudesFromDatabase();
    }

    private void loadGratitudesFromDatabase() {
        gratitudeList.clear();
        Cursor cursor = database.query(GratitudeDatabaseHelper.TABLE_GRATITUDE,
                new String[]{GratitudeDatabaseHelper.COLUMN_ID, GratitudeDatabaseHelper.COLUMN_MESSAGE, GratitudeDatabaseHelper.COLUMN_DATE},
                null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(GratitudeDatabaseHelper.COLUMN_ID));
                String message = cursor.getString(cursor.getColumnIndexOrThrow(GratitudeDatabaseHelper.COLUMN_MESSAGE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(GratitudeDatabaseHelper.COLUMN_DATE));
                gratitudeList.add(new Gratitude(id, message, date));
            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    public void addGratitudeToDatabase(Gratitude gratitude) {
        ContentValues values = new ContentValues();
        values.put(GratitudeDatabaseHelper.COLUMN_MESSAGE, gratitude.getMessage());
        values.put(GratitudeDatabaseHelper.COLUMN_DATE, gratitude.getDate());
        long newRowId = database.insert(GratitudeDatabaseHelper.TABLE_GRATITUDE, null, values);
        if (newRowId != -1) {
            gratitude.setId((int) newRowId);
            gratitudeList.add(gratitude);
            notifyDataSetChanged();
        }
    }

    private void updateGratitudeInDatabase(Gratitude gratitude) {
        ContentValues values = new ContentValues();
        values.put(GratitudeDatabaseHelper.COLUMN_MESSAGE, gratitude.getMessage());
        values.put(GratitudeDatabaseHelper.COLUMN_DATE, gratitude.getDate());
        database.update(GratitudeDatabaseHelper.TABLE_GRATITUDE, values,
                GratitudeDatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(gratitude.getId())});
        notifyDataSetChanged();
    }

    private void deleteGratitudeFromDatabase(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Xác nhận xóa");
        builder.setMessage("Bạn có chắc chắn muốn xóa mục này?");

        builder.setPositiveButton(android.R.string.yes, (dialog, which) -> {
            long id = gratitudeList.get(position).getId();
            database.delete(GratitudeDatabaseHelper.TABLE_GRATITUDE,
                    GratitudeDatabaseHelper.COLUMN_ID + " = ?",
                    new String[]{String.valueOf(id)});
            gratitudeList.remove(position);
            notifyDataSetChanged();
            Toast.makeText(context, "Đã xóa mục tại vị trí " + position, Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton(android.R.string.no, (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_gratitude, parent, false);

            holder = new ViewHolder();
            holder.tvGratitudeMessage = convertView.findViewById(R.id.tvGratitudeMessage);
            holder.tvGratitudeDate = convertView.findViewById(R.id.tvGratitudeDate);
            holder.btnEdit = convertView.findViewById(R.id.btnEdit);
            holder.btnDelete = convertView.findViewById(R.id.btnDelete);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final Gratitude gratitude = gratitudeList.get(position);

        holder.tvGratitudeMessage.setText(gratitude.getMessage());
        holder.tvGratitudeDate.setText(gratitude.getDate());

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog(gratitude, position);
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteGratitudeFromDatabase(position);
                Toast.makeText(context, "Đã xóa mục tại vị trí " + position, Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }

    private void showEditDialog(final Gratitude gratitude, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Chỉnh sửa lời biết ơn");

        View viewInflated = LayoutInflater.from(context).inflate(R.layout.dialog_edit_gratitude, null, false);
        final EditText input = viewInflated.findViewById(R.id.etEditGratitudeMessage);
        input.setText(gratitude.getMessage());
        builder.setView(viewInflated);

        builder.setPositiveButton(android.R.string.ok, (dialog, which) -> {
            dialog.dismiss();
            String newMessage = input.getText().toString().trim();
            if (!newMessage.isEmpty()) {
                gratitude.setMessage(newMessage);
                updateGratitudeInDatabase(gratitude);
                notifyDataSetChanged();
                Toast.makeText(context, "Đã cập nhật mục tại vị trí " + position, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Nội dung không thể để trống", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton(android.R.string.cancel, (dialog, which) -> dialog.cancel());

        builder.show();
    }

    public static class ViewHolder {
        TextView tvGratitudeMessage;
        TextView tvGratitudeDate;
        ImageButton btnEdit;
        ImageButton btnDelete;
    }
}
