package com.example.asm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageButton btnGratitude, btnPersonalInfo, btnExerciseManagementActivity, btnAccountInfo;
    private TextView tvUsername;
    private String username;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ các phần tử giao diện
        tvUsername = findViewById(R.id.tvUsername);
        btnAccountInfo = findViewById(R.id.btnAccountInfo);
        btnGratitude = findViewById(R.id.btnGratitude);
        btnPersonalInfo = findViewById(R.id.btnPersonalInfoActivity);
        btnExerciseManagementActivity = findViewById(R.id.btnExerciseManagementActivity);

        // Lấy username từ Intent
        username = getIntent().getStringExtra("username");
        if (username != null && !username.isEmpty()) {
            tvUsername.setText("Xin chào, " + username);
        } else {
            tvUsername.setText("Xin chào, người dùng");
        }

        // Thiết lập sự kiện cho các nút bấm
        btnGratitude.setOnClickListener(v -> navigateToGratitudeActivity());
        btnPersonalInfo.setOnClickListener(v -> navigatePersonalInfoActivity());
        btnExerciseManagementActivity.setOnClickListener(v -> navigateExerciseManagementActivity());
        btnAccountInfo.setOnClickListener(v -> navigateAccountInfoActivity());

        // Áp dụng insets cho layout chính
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void navigateToGratitudeActivity() {
        Intent intent = new Intent(this, GratitudeActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    public void navigatePersonalInfoActivity() {
        Intent intent = new Intent(this, PersonalInfoActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    public void navigateExerciseManagementActivity() {
        Intent intent = new Intent(this, ExerciseManagementActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    public void navigateAccountInfoActivity() {
        Intent intent = new Intent(this, AccountInfoActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }
}
