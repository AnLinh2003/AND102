package com.example.asm;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    private static final String TAG = "ChangePasswordActivity";

    private TextView tvUsername;
    private EditText etOldPassword, etNewPassword, etConfirmPassword;
    private Button btnSubmit, btnCancel;

    private String username; // Đảm bảo biến này được gán giá trị chính xác

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password_activity);

        etOldPassword = findViewById(R.id.etOldPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnCancel = findViewById(R.id.btnCancel);

        tvUsername = findViewById(R.id.tvUsername); // Ánh xạ TextView từ layout

        // Lấy tên người dùng từ Intent
        username = getIntent().getStringExtra("username");
        if (username != null) {
            tvUsername.setText("Tên tài khoản: " + username); // Hiển thị tên người dùng trên TextView
            Log.d(TAG, "Tên người dùng: " + username);
        } else {
            Log.e(TAG, "Tên người dùng không được lấy từ Intent.");
            Toast.makeText(this, "Không tìm thấy tên người dùng", Toast.LENGTH_SHORT).show();
            finish(); // Kết thúc Activity nếu không tìm thấy tên người dùng
        }

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Nhấn nút đồng ý.");
                changePassword();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Nhấn nút hủy bỏ.");
                finish();
            }
        });
    }

    private void changePassword() {
        String oldPassword = etOldPassword.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        if (isValidPassword(oldPassword, newPassword, confirmPassword)) {
            DBHelper dbHelper = new DBHelper(this);
            boolean updated = false;
            try {
                if (username != null) {
                    updated = dbHelper.updateNewPassword(username, oldPassword, newPassword); // Cập nhật mật khẩu mới cho tên người dùng
                    Log.d(TAG, "Cập nhật mật khẩu thành công: " + updated);
                } else {
                    Log.e(TAG, "Tên người dùng không hợp lệ.");
                }
            } catch (Exception e) {
                Log.e(TAG, "Lỗi khi cập nhật mật khẩu: " + e.getMessage());
            } finally {
                dbHelper.close();
            }

            if (updated) {
                Toast.makeText(ChangePasswordActivity.this, "Đổi mật khẩu thành công", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(ChangePasswordActivity.this, "Đổi mật khẩu thất bại", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean isValidPassword(String oldPassword, String newPassword, String confirmPassword) {
        if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!newPassword.equals(confirmPassword)) {
            Toast.makeText(this, "Mật khẩu mới không khớp", Toast.LENGTH_SHORT).show();
            return false;
        } else if (newPassword.length() < 6) {
            Toast.makeText(this, "Mật khẩu mới phải có ít nhất 6 ký tự", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
