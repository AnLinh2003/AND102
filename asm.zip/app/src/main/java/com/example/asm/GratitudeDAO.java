package com.example.asm;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class GratitudeDAO {

    private DBHelper dbHelper;

    public GratitudeDAO(Context context) {
        dbHelper = new DBHelper(context);
    }

    // Thêm một lời biết ơn vào cơ sở dữ liệu
    public boolean addGratitude(String gratitudeMessage) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("GRATITUDE_MESSAGE", gratitudeMessage);
        long result = db.insert("GRATITUDE_TABLE", null, contentValues);
        return result != -1;
    }

    // Lấy danh sách các lời biết ơn từ cơ sở dữ liệu
    public List<String> getAllGratitudes() {
        List<String> gratitudes = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM GRATITUDE_TABLE", null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String gratitudeMessage = cursor.getString(cursor.getColumnIndex("GRATITUDE_MESSAGE"));
                gratitudes.add(gratitudeMessage);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return gratitudes;
    }

    // Xóa một lời biết ơn từ cơ sở dữ liệu
    public boolean deleteGratitude(String gratitudeMessage) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        return db.delete("GRATITUDE_TABLE", "GRATITUDE_MESSAGE = ?", new String[]{gratitudeMessage}) > 0;
    }

    // Cập nhật một lời biết ơn trong cơ sở dữ liệu
    public boolean updateGratitude(String oldGratitude, String newGratitude) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("GRATITUDE_MESSAGE", newGratitude);
        return db.update("GRATITUDE_TABLE", contentValues, "GRATITUDE_MESSAGE = ?", new String[]{oldGratitude}) > 0;
    }
}
