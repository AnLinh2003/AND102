package com.example.asm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ExerciseManagementActivity extends AppCompatActivity {

    private TextView tvTotalSteps, tvGoalSteps;
    private Button btnUpdateGoal;
    private ListView lvExerciseHistory;
    private ImageButton btnBack, ivCalendarIcon;

    private ExerciseManagementDAO exerciseManagementDAO;
    private ExerciseManagementAdapter exerciseManagementAdapter;
    private List<ExerciseManagement> exerciseList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_management);

        tvTotalSteps = findViewById(R.id.tvTotalSteps);
        tvGoalSteps = findViewById(R.id.tvGoalSteps);
        btnUpdateGoal = findViewById(R.id.btnUpdateGoal);
        lvExerciseHistory = findViewById(R.id.lvExerciseHistory);
        btnBack = findViewById(R.id.btnBack);
        ivCalendarIcon = findViewById(R.id.ivCalendarIcon);

        exerciseManagementDAO = new ExerciseManagementDAO(this);
        exerciseList = exerciseManagementDAO.getAllExercises();
        exerciseManagementAdapter = new ExerciseManagementAdapter(this, R.layout.activity_exercise_management, exerciseList);
        lvExerciseHistory.setAdapter(exerciseManagementAdapter);

        btnUpdateGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý logic cập nhật mục tiêu bước đi
                try {
                    int newGoalSteps = Integer.parseInt(tvGoalSteps.getText().toString());
                    for (ExerciseManagement exercise : exerciseList) {
                        exercise.setGoalSteps(newGoalSteps);
                        exerciseManagementDAO.updateExercise(exercise);
                    }
                    Toast.makeText(ExerciseManagementActivity.this, "Cập nhật mục tiêu bước đi thành công", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(ExerciseManagementActivity.this, "Định dạng số không hợp lệ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Đóng activity và quay lại màn hình trước đó
            }
        });

        ivCalendarIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Hiển thị date picker (nếu cần thiết)
                Toast.makeText(ExerciseManagementActivity.this, "Đã nhấn vào biểu tượng lịch", Toast.LENGTH_SHORT).show();
            }
        });

        // Hiển thị tổng số bước đi và mục tiêu bước đi
        int totalSteps = 0;
        int goalSteps = 0;
        for (ExerciseManagement exercise : exerciseList) {
            totalSteps += exercise.getTotalSteps();
            goalSteps = exercise.getGoalSteps();
        }
        tvTotalSteps.setText(String.valueOf(totalSteps));
        tvGoalSteps.setText(String.valueOf(goalSteps));
    }
}
