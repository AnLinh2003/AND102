package com.example.asm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AccountInfoActivity extends AppCompatActivity {

    TextView tvUsername;
    ImageButton btnBack, btnChangePassword, btnLogout;
    ImageView imageAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_info);

        tvUsername = findViewById(R.id.tvUsername);
        btnBack = findViewById(R.id.btnBack);
        btnChangePassword = findViewById(R.id.btnChangePassword);
        btnLogout = findViewById(R.id.btnLogout);
        imageAccount = findViewById(R.id.imageAccount);

        // Lấy username từ Intent
        String username = getIntent().getStringExtra("username");
        if (username != null && !username.isEmpty()) {
            tvUsername.setText(username);
        } else {
            tvUsername.setText("Không có tên đăng nhập");
        }

        // Xử lý nút back
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Quay về MainActivity và truyền lại username
                Intent intent = new Intent(AccountInfoActivity.this, MainActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            }
        });

        // Xử lý đổi mật khẩu
        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến ChangePasswordActivity
                Intent intent = new Intent(AccountInfoActivity.this, ChangePasswordActivity.class);
                intent.putExtra("username", username); // Truyền username nếu cần
                startActivity(intent);
            }
        });

        // Xử lý đăng xuất
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Hiển thị thông báo đăng xuất thành công
                Toast.makeText(AccountInfoActivity.this, "Đăng xuất thành công", Toast.LENGTH_SHORT).show();

                // Đăng xuất và quay về LoginActivity
                Intent intent = new Intent(AccountInfoActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
