package com.example.asm;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    // Database info
    private static final String DATABASE_NAME = "Users.db";
    private static final int DATABASE_VERSION = 2; // Bump version number for schema change

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "ID";
    private static final String COL_USERNAME = "USERNAME";
    private static final String COL_PASSWORD = "PASSWORD";
    private static final String COL_NEW_PASSWORD = "NEW_PASSWORD"; // New column for new password

    // Gratitude table
    private static final String TABLE_GRATITUDE = "gratitude";
    private static final String COL_GRATITUDE_ID = "ID";
    private static final String COL_GRATITUDE_MESSAGE = "MESSAGE";

    // Exercise management table
    private static final String TABLE_EXERCISE = "exercise";
    private static final String COL_EXERCISE_ID = "ID";
    private static final String COL_EXERCISE_DATE = "DATE";
    private static final String COL_EXERCISE_STEPS = "STEPS";
    private static final String COL_EXERCISE_GOAL = "GOAL";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT, " +
                COL_NEW_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        // Create gratitude table
        String createGratitudeTable = "CREATE TABLE " + TABLE_GRATITUDE + " (" +
                COL_GRATITUDE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_GRATITUDE_MESSAGE + " TEXT)";
        db.execSQL(createGratitudeTable);

        // Create exercise table
        String createExerciseTable = "CREATE TABLE " + TABLE_EXERCISE + " (" +
                COL_EXERCISE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EXERCISE_DATE + " TEXT, " +
                COL_EXERCISE_STEPS + " INTEGER, " +
                COL_EXERCISE_GOAL + " INTEGER)";
        db.execSQL(createExerciseTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GRATITUDE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXERCISE);

        // Create tables again
        onCreate(db);
    }

    // Insert a new user into the database
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close(); // Close the database connection
        return result != -1;
    }

    // Check if a user exists in the database
    public boolean checkUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COL_USERNAME };
        String selection = COL_USERNAME + "=?";
        String[] selectionArgs = { username };
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close(); // Close the database connection
        return exists;
    }

    // Authenticate a user
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COL_USERNAME };
        String selection = COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        String[] selectionArgs = { username, password };
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean authenticated = cursor.getCount() > 0;
        cursor.close();
        db.close(); // Close the database connection
        return authenticated;
    }

    // Update user password
    public boolean updatePassword(String username, String oldPassword, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        // First, verify the old password
        String[] columns = { COL_PASSWORD };
        String selection = COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        String[] selectionArgs = { username, oldPassword };
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean passwordMatches = cursor.getCount() > 0;
        cursor.close();

        if (passwordMatches) {
            // If password matches, update to new password
            ContentValues values = new ContentValues();
            values.put(COL_PASSWORD, newPassword);
            String whereClause = COL_USERNAME + "=?";
            String[] whereArgs = { username };
            int result = db.update(TABLE_USERS, values, whereClause, whereArgs);
            db.close(); // Close the database connection
            return result > 0;
        } else {
            db.close(); // Close the database connection
            return false;
        }
    }

    // Insert a gratitude message into the database
    public boolean insertGratitudeMessage(String message) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_GRATITUDE_MESSAGE, message);
        long result = db.insert(TABLE_GRATITUDE, null, values);
        db.close(); // Close the database connection
        return result != -1;
    }

    // Retrieve all gratitude messages from the database
    public List<String> getAllGratitudeMessages() {
        List<String> messages = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GRATITUDE, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String message = cursor.getString(cursor.getColumnIndex(COL_GRATITUDE_MESSAGE));
                messages.add(message);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close(); // Close the database connection
        return messages;
    }

    // Delete a gratitude message from the database
    public boolean deleteGratitudeMessage(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COL_GRATITUDE_ID + "=?";
        String[] whereArgs = { String.valueOf(id) };
        int result = db.delete(TABLE_GRATITUDE, whereClause, whereArgs);
        db.close(); // Close the database connection
        return result > 0;
    }

    // Insert exercise data into the database
    public boolean insertExerciseData(String date, int steps, int goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EXERCISE_DATE, date);
        values.put(COL_EXERCISE_STEPS, steps);
        values.put(COL_EXERCISE_GOAL, goal);
        long result = db.insert(TABLE_EXERCISE, null, values);
        db.close(); // Close the database connection
        return result != -1;
    }

    // Retrieve all exercise data from the database
    @SuppressLint("Range")
    public List<ExerciseManagement> getAllExerciseData() {
        List<ExerciseManagement> exerciseDataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EXERCISE, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(COL_EXERCISE_ID));
                String date = cursor.getString(cursor.getColumnIndex(COL_EXERCISE_DATE));
                int steps = cursor.getInt(cursor.getColumnIndex(COL_EXERCISE_STEPS));
                int goal = cursor.getInt(cursor.getColumnIndex(COL_EXERCISE_GOAL));
                exerciseDataList.add(new ExerciseManagement(id, date, steps, goal));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close(); // Close the database connection
        return exerciseDataList;
    }

    // Update exercise data in the database
    public boolean updateExerciseData(int id, String date, int steps, int goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EXERCISE_DATE, date);
        values.put(COL_EXERCISE_STEPS, steps);
        values.put(COL_EXERCISE_GOAL, goal);
        String whereClause = COL_EXERCISE_ID + "=?";
        String[] whereArgs = { String.valueOf(id) };
        int result = db.update(TABLE_EXERCISE, values, whereClause, whereArgs);
        db.close(); // Close the database connection
        return result > 0;
    }

    // Delete exercise data from the database
    public boolean deleteExerciseData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COL_EXERCISE_ID + "=?";
        String[] whereArgs = { String.valueOf(id) };
        int result = db.delete(TABLE_EXERCISE, whereClause, whereArgs);
        db.close(); // Close the database connection
        return result > 0;
    }
    @SuppressLint("Range")
    public String getCurrentUsername() {
        String username = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COL_USERNAME };
        Cursor cursor = db.query(TABLE_USERS, columns, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            username = cursor.getString(cursor.getColumnIndex(COL_USERNAME));
        }
        cursor.close();
        db.close(); // Close the database connection
        return username;
    }
    // Update new password for user in the database
    public boolean updateNewPassword(String username, String newPassword, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NEW_PASSWORD, newPassword);
        String whereClause = COL_USERNAME + "=?";
        String[] whereArgs = { username };
        int result = db.update(TABLE_USERS, values, whereClause, whereArgs);
        db.close(); // Close the database connection
        return result > 0;
    }

    public String getUsername() {
        return null;
    }

}

